/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


  /* Este código se ejecutará directamente donde se incluya */
 document.write("<p>Fecha Mostrada desde Archivo Externo->" + Date() + "</p>")    
 document.write("<p>Fecha Mostrada desde Archivo Externo->" + Date() + "</p>")    
